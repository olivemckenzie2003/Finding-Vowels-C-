//One line comment

//This brings in the iostream library
#include <iostream>

/*
    This is a block comment that englobes multiple
    lines of text
*/




int main(){
    //This is going to print "Hello World" to the console
    std::cout << "Hello World!" << std::endl;
    return 0;
    //Program ends here
}