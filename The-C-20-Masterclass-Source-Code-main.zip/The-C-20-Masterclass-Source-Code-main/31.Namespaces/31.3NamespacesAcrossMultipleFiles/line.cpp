#include "line.h"

namespace Geom{
    
    Line::Line(const Point& start, const Point& end)
        : m_start{start}, m_end{end}
    {
    }
}



